# Sonu Kumar - Personal Portfolio Website

A modern, responsive personal portfolio website built with HTML, CSS, and JavaScript. This portfolio features a dark theme with gradient accents and smooth animations, perfectly matching the reference design.

## 🎨 Design Features

- **Dark Theme**: Rich black background (#1e1e1e) with white text
- **Gradient Accents**: Pink to purple gradients (#ec4899 to #8b5cf6) for buttons and highlights
- **Warm Amber**: Accent color (#f59e0b) for highlights and stats
- **Modern Typography**: Inter font family for clean, professional look
- **Responsive Design**: Fully responsive for mobile, tablet, and desktop

## 📱 Sections Included

1. **Header**: Fixed navigation with logo and menu
2. **Hero Section**: Profile image, introduction, and call-to-action buttons
3. **About Me**: Bio, skill bars with animations, and statistics
4. **Services**: 6 service cards with hover effects
5. **Portfolio**: Project gallery with overlay effects
6. **Contact**: Contact form with validation and contact information
7. **Footer**: Newsletter subscription and links

## 🚀 Features

### Interactive Elements
- Smooth scrolling navigation
- Animated skill bars
- Hover effects on cards and buttons
- Mobile-responsive menu
- Contact form validation
- Newsletter subscription
- Scroll progress indicator
- Loading animations

### Animations
- Fade-in animations on scroll
- Skill bar progress animations
- Button hover effects
- Portfolio item overlays
- Smooth transitions

## 📁 File Structure

```
portfolio/
├── index.html          # Main HTML structure
├── style.css           # All styling and responsive design
├── script.js           # JavaScript functionality
├── send_email.php      # PHP backend for email sending
├── test_email.php      # Test file for email functionality
├── email_log.txt       # Email submission logs (auto-generated)
└── README.md           # This file
```

## 🛠️ How to Use

1. **Upload to web server**: All files must be uploaded to a server with PHP support
2. **Test email functionality**: Visit `test_email.php` to verify email setup
3. **Open the website**: Open `index.html` in your web browser
4. **Customize content**: Edit the HTML file to update your information
5. **Modify styling**: Update `style.css` to change colors, fonts, or layout
6. **Add functionality**: Enhance `script.js` with additional features

## 📧 Email Functionality Setup

### Requirements:
- **Web Server**: Must support PHP (version 7.0 or higher)
- **Mail Function**: PHP `mail()` function must be enabled
- **File Permissions**: Directory must be writable for log files

### Testing:
1. Upload files to your web server
2. Visit `yourdomain.com/test_email.php` to test email functionality
3. Check if you receive the test email at `creativedigitalwork73@gmail.com`

### Troubleshooting:
- If emails aren't sending, check your hosting provider's mail settings
- Some shared hosting providers require SMTP configuration
- Check the `email_log.txt` file for submission records

## 🎯 Customization Guide

### Changing Personal Information

Edit the following sections in `index.html`:

```html
<!-- Update name and title -->
<title>Your Name - Frontend Developer Portfolio</title>
<div class="logo"><h2>Your Name</h2></div>

<!-- Update hero section -->
<h1>I'm <span class="highlight">Your Name</span>, frontend developer based in Your Location.</h1>
<p>Your introduction text here...</p>

<!-- Update about section -->
<p>Your bio text here...</p>

<!-- Update contact information -->
<span>your.email@example.com</span>
<span>+1-234-567-8900</span>
<span>Your City, Country</span>
```

### Changing Colors

Update the CSS variables in `style.css`:

```css
/* Main colors */
--background: #1e1e1e;        /* Background color */
--text-color: #ffffff;         /* Text color */
--accent: #f59e0b;            /* Amber accent */
--gradient-start: #ec4899;    /* Pink gradient start */
--gradient-end: #8b5cf6;      /* Purple gradient end */
```

### Adding New Sections

1. Add HTML structure in `index.html`
2. Add corresponding CSS in `style.css`
3. Add any JavaScript functionality in `script.js`

## 📱 Responsive Breakpoints

- **Desktop**: 1200px and above
- **Tablet**: 768px to 1199px
- **Mobile**: Below 768px

## 🌟 Browser Support

- Chrome (latest)
- Firefox (latest)
- Safari (latest)
- Edge (latest)
- Mobile browsers

## 🔧 Technical Details

### CSS Features
- CSS Grid and Flexbox for layouts
- CSS Custom Properties (variables)
- CSS Animations and Transitions
- Media Queries for responsiveness
- Backdrop filters for glass effects

### JavaScript Features
- Intersection Observer API for scroll animations
- Form validation
- Event handling
- DOM manipulation
- Smooth scrolling

### Performance Optimizations
- Optimized images with proper sizing
- Efficient CSS selectors
- Minimal JavaScript bundle
- Smooth animations with hardware acceleration

## 📧 Contact Form

The contact form includes:
- Name validation
- Email validation
- Message validation
- Success/error notifications
- Form reset after submission

## 📬 Newsletter Subscription

The footer includes a newsletter subscription feature with:
- Email validation
- Success notifications
- Form reset after subscription

## 🎨 Color Palette

- **Primary Background**: #1e1e1e (Rich Black)
- **Text**: #ffffff (White)
- **Secondary Text**: #cccccc (Light Gray)
- **Accent**: #f59e0b (Warm Amber)
- **Gradient Start**: #ec4899 (Pink)
- **Gradient End**: #8b5cf6 (Purple)
- **Borders**: rgba(255, 255, 255, 0.1) (Semi-transparent White)

## 🔄 Updates and Maintenance

To keep your portfolio up to date:

1. **Regular content updates**: Update projects, skills, and experience
2. **Image optimization**: Compress images for better performance
3. **Link maintenance**: Check and update external links
4. **Browser testing**: Test on different browsers and devices

## 📄 License

This portfolio template is free to use and modify for personal and commercial projects.

## 🤝 Support

If you need help customizing this portfolio or have questions, feel free to reach out!

---

**Built with ❤️ using HTML, CSS, and JavaScript**
#   P o r t f o l i o  
 